# Using Regex on AWS RDS

![SQL Regex Logo](/images/sql-regex-logo.png)

* http://notebookheavy.com/2012/05/23/how-to-use-sql-clr-in-amazon-aws-rds/